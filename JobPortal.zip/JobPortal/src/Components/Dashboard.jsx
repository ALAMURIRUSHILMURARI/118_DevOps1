import React from 'react'

const Dashboard = () => {
  return (
    <div>
      Dashboard PAge
    </div>
  )
}

export default Dashboard
